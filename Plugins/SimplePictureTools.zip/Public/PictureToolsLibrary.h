// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "PictureToolsLibrary.generated.h"

/**
 * 
 */
UCLASS()
class SIMPLEPICTURETOOLS_API UPictureToolsLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintCallable, Category = "Picture Tool")
	static bool LoadImageToTexture2D(const FString& ImagePath,UTexture2D* &InTexture,float& Width,float& Height);
	UFUNCTION(BlueprintCallable, Category = "Picture Tool")
	static bool LoadImageToDyTexture2D(const FString& ImagePath, UTexture2DDynamic* &InDyTexture, float& Width, float& Height);
	UFUNCTION(BlueprintCallable, Category = "Picture Tool")
	static bool SaveImageFromTexture2D(UTexture2D* InTex,const FString& DesPath);
	UFUNCTION(BlueprintCallable, Category = "Picture Tool")
	static bool CreateTexture2DAsset(const FString& ImagePath);
private:
	static bool LoadImageToData(const FString& ImagePath, TArray64<uint8>&OutData, float& Width, float& Height);
};
